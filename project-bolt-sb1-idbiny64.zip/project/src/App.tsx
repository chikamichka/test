import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout } from './components/layout/Layout';
import { Home } from './pages/Home';
import { Profile } from './pages/Profile';
import { AuthProvider } from './context/AuthContext';
import { TweetProvider } from './context/TweetContext';
import { HealthProvider } from './context/HealthContext';

function App() {
  return (
    <AuthProvider>
      <TweetProvider>
        <HealthProvider>
          <Router>
            <Layout>
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/profile/:username" element={<Profile />} />
              </Routes>
            </Layout>
          </Router>
        </HealthProvider>
      </TweetProvider>
    </AuthProvider>
  );
}

export default App;