import { HealthClassification } from '../types/Health';

const API_URL = 'http://127.0.0.1:8000/classify_post';

export const classifyTweetHealth = async (text: string): Promise<HealthClassification> => {
  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return {
      category: data.category as 'Healthy' | 'Unhealthy',
      confidence: data.confidence,
      detail: data.detail,
      persuasive_message: data.persuasive_message
    };
  } catch (error) {
    console.error('Error classifying tweet:', error);
    
    // Fallback classification if the API call fails
    return {
      category: 'Healthy',
      confidence: 0,
      detail: 'Error connecting to classification service',
      persuasive_message: ''
    };
  }
};