import React, { createContext, useState, useContext, useEffect } from 'react';
import { Tweet } from '../types/Tweet';
import { HealthClassification } from '../types/Health';
import { mockHealthBot } from '../data/mockData';
import { useAuth } from './AuthContext';
import { useTweets } from './TweetContext';
import { classifyTweetHealth } from '../services/healthService';

interface HealthContextType {
  classifications: Record<string, HealthClassification>;
  classifyTweet: (tweet: Tweet) => Promise<void>;
  healthResponses: Tweet[];
}

const HealthContext = createContext<HealthContextType>({
  classifications: {},
  classifyTweet: async () => {},
  healthResponses: [],
});

export const useHealth = () => useContext(HealthContext);

export const HealthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [classifications, setClassifications] = useState<Record<string, HealthClassification>>({});
  const [healthResponses, setHealthResponses] = useState<Tweet[]>([]);
  const { users } = useAuth();
  const { tweets } = useTweets();

  // Get the health advisor bot account
  const healthBot = users.find(user => user.username === 'healthadvisor');

  // This function classifies a tweet and triggers a health advisor response if needed
  const classifyTweet = async (tweet: Tweet) => {
    try {
      // Don't classify the health bot's own tweets
      if (tweet.authorId === healthBot?.id) return;

      // Classify the tweet using our service
      const classification = await classifyTweetHealth(tweet.content);
      
      // Store the classification
      setClassifications(prev => ({
        ...prev,
        [tweet.id]: classification
      }));

      // If unhealthy and we have a health bot, create a response
      if (classification.category === 'Unhealthy' && healthBot) {
        // Create a response tweet from the health bot
        const responseTweet: Tweet = {
          id: `response-${tweet.id}`,
          content: classification.persuasive_message,
          authorId: healthBot.id,
          author: healthBot,
          likes: [],
          retweets: [],
          replies: [],
          createdAt: new Date().toISOString(),
          inReplyTo: tweet.id,
        };

        // Add to health responses
        setHealthResponses(prev => [responseTweet, ...prev]);
      }
    } catch (error) {
      console.error('Error classifying tweet:', error);
    }
  };

  // Initial classification of all tweets
  useEffect(() => {
    if (tweets.length > 0 && Object.keys(classifications).length === 0) {
      // Classify existing tweets
      tweets.forEach(tweet => {
        if (!classifications[tweet.id]) {
          classifyTweet(tweet);
        }
      });
    }
  }, [tweets]);

  return (
    <HealthContext.Provider value={{ 
      classifications, 
      classifyTweet,
      healthResponses
    }}>
      {children}
    </HealthContext.Provider>
  );
};