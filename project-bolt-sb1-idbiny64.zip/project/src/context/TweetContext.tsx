import React, { createContext, useState, useContext, useEffect } from 'react';
import { Tweet } from '../types/Tweet';
import { mockTweets } from '../data/mockData';
import { useAuth } from './AuthContext';
import { v4 as uuidv4 } from 'uuid';
import { useHealth } from './HealthContext';

interface TweetContextType {
  tweets: Tweet[];
  createTweet: (content: string) => void;
  likeTweet: (tweetId: string) => void;
  retweet: (tweetId: string) => void;
  reply: (tweetId: string, content: string) => void;
  getUserTweets: (username: string) => Tweet[];
}

const TweetContext = createContext<TweetContextType>({
  tweets: [],
  createTweet: () => {},
  likeTweet: () => {},
  retweet: () => {},
  reply: () => {},
  getUserTweets: () => [],
});

export const useTweets = () => useContext(TweetContext);

export const TweetProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tweets, setTweets] = useState<Tweet[]>(mockTweets);
  const { currentUser, users } = useAuth();
  const { classifyTweet } = useHealth();

  // Sort tweets by creation date (newest first)
  useEffect(() => {
    setTweets(prevTweets => 
      [...prevTweets].sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      )
    );
  }, []);

  const createTweet = (content: string) => {
    if (!currentUser) return;

    const newTweet: Tweet = {
      id: uuidv4(),
      content,
      authorId: currentUser.id,
      author: currentUser,
      likes: [],
      retweets: [],
      replies: [],
      createdAt: new Date().toISOString(),
    };

    setTweets(prevTweets => [newTweet, ...prevTweets]);

    // Classify the tweet for health content
    classifyTweet(newTweet);
  };

  const likeTweet = (tweetId: string) => {
    if (!currentUser) return;

    setTweets(prevTweets =>
      prevTweets.map(tweet => {
        if (tweet.id === tweetId) {
          const userLiked = tweet.likes.includes(currentUser.id);
          const updatedLikes = userLiked
            ? tweet.likes.filter(id => id !== currentUser.id)
            : [...tweet.likes, currentUser.id];
          
          return { ...tweet, likes: updatedLikes };
        }
        return tweet;
      })
    );
  };

  const retweet = (tweetId: string) => {
    if (!currentUser) return;

    setTweets(prevTweets =>
      prevTweets.map(tweet => {
        if (tweet.id === tweetId) {
          const userRetweeted = tweet.retweets.includes(currentUser.id);
          const updatedRetweets = userRetweeted
            ? tweet.retweets.filter(id => id !== currentUser.id)
            : [...tweet.retweets, currentUser.id];
          
          return { ...tweet, retweets: updatedRetweets };
        }
        return tweet;
      })
    );
  };

  const reply = (tweetId: string, content: string) => {
    if (!currentUser) return;

    const replyTweet: Tweet = {
      id: uuidv4(),
      content,
      authorId: currentUser.id,
      author: currentUser,
      likes: [],
      retweets: [],
      replies: [],
      createdAt: new Date().toISOString(),
      inReplyTo: tweetId,
    };

    setTweets(prevTweets => {
      // Add the new reply to the tweets array
      const updatedTweets = [replyTweet, ...prevTweets];
      
      // Update the original tweet's replies array
      return updatedTweets.map(tweet => {
        if (tweet.id === tweetId) {
          return {
            ...tweet,
            replies: [...tweet.replies, replyTweet.id],
          };
        }
        return tweet;
      });
    });

    // Classify the reply for health content
    classifyTweet(replyTweet);
  };

  const getUserTweets = (username: string) => {
    const user = users.find(u => u.username === username);
    if (!user) return [];
    
    return tweets.filter(tweet => 
      tweet.authorId === user.id && !tweet.inReplyTo
    );
  };

  return (
    <TweetContext.Provider value={{ 
      tweets, 
      createTweet, 
      likeTweet, 
      retweet, 
      reply,
      getUserTweets 
    }}>
      {children}
    </TweetContext.Provider>
  );
};