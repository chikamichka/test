import React, { useState } from 'react';
import { Image, Smile, Calendar, MapPin } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTweets } from '../../context/TweetContext';

interface CreateTweetProps {
  placeholder?: string;
  inReplyTo?: string;
  onTweetCreated?: () => void;
}

export const CreateTweet: React.FC<CreateTweetProps> = ({ 
  placeholder = "What's happening?",
  inReplyTo,
  onTweetCreated
}) => {
  const [content, setContent] = useState('');
  const { currentUser } = useAuth();
  const { createTweet, reply } = useTweets();
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!content.trim()) return;
    
    if (inReplyTo) {
      reply(inReplyTo, content);
    } else {
      createTweet(content);
    }
    
    setContent('');
    if (onTweetCreated) {
      onTweetCreated();
    }
  };
  
  return (
    <div className="p-4 border-b border-gray-200 dark:border-gray-800">
      {currentUser && (
        <div className="flex gap-4">
          <img 
            src={currentUser.avatar || 'https://images.pexels.com/photos/771742/pexels-photo-771742.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'} 
            alt={currentUser.displayName} 
            className="w-12 h-12 rounded-full"
          />
          <div className="flex-1">
            <form onSubmit={handleSubmit}>
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder={placeholder}
                className="w-full border-0 focus:ring-0 text-xl bg-transparent resize-none min-h-[120px]"
              />
              <div className="flex items-center justify-between pt-2 border-t border-gray-200 dark:border-gray-800">
                <div className="flex gap-2 text-blue-500">
                  <button type="button" className="p-2 rounded-full hover:bg-blue-50 dark:hover:bg-blue-900/20">
                    <Image size={20} />
                  </button>
                  <button type="button" className="p-2 rounded-full hover:bg-blue-50 dark:hover:bg-blue-900/20">
                    <Smile size={20} />
                  </button>
                  <button type="button" className="p-2 rounded-full hover:bg-blue-50 dark:hover:bg-blue-900/20">
                    <Calendar size={20} />
                  </button>
                  <button type="button" className="p-2 rounded-full hover:bg-blue-50 dark:hover:bg-blue-900/20">
                    <MapPin size={20} />
                  </button>
                </div>
                <button
                  type="submit"
                  disabled={!content.trim()}
                  className={`bg-blue-500 text-white px-4 py-2 rounded-full font-bold ${
                    !content.trim() 
                      ? 'opacity-50 cursor-not-allowed' 
                      : 'hover:bg-blue-600'
                  }`}
                >
                  {inReplyTo ? 'Reply' : 'Tweet'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};