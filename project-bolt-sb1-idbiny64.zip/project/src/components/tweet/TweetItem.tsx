import React, { useState } from 'react';
import { Heart, MessageCircle, Repeat, Share, MoreHorizontal, AlertCircle, Check } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTweets } from '../../context/TweetContext';
import { Tweet } from '../../types/Tweet';
import { useHealth } from '../../context/HealthContext';
import { TweetReplyModal } from './TweetReplyModal';
import { formatDistanceToNow } from '../../utils/dateUtils';

interface TweetItemProps {
  tweet: Tweet;
  showReplies?: boolean;
}

export const TweetItem: React.FC<TweetItemProps> = ({ tweet, showReplies = false }) => {
  const { currentUser } = useAuth();
  const { tweets, likeTweet, retweet } = useTweets();
  const { classifications, healthResponses } = useHealth();
  const [replyModalOpen, setReplyModalOpen] = useState(false);
  
  if (!tweet) return null;
  
  const isLiked = currentUser && tweet.likes.includes(currentUser.id);
  const isRetweeted = currentUser && tweet.retweets.includes(currentUser.id);
  
  // Get health classification if it exists
  const healthClass = classifications[tweet.id];
  const isUnhealthy = healthClass?.category === 'Unhealthy';
  
  // Find health advisor response to this tweet
  const healthResponse = healthResponses.find(response => response.inReplyTo === tweet.id);
  
  // Get replies to this tweet
  const tweetReplies = tweets.filter(t => t.inReplyTo === tweet.id);
  
  // Format relative time (e.g., "2h ago")
  const timeAgo = formatDistanceToNow(new Date(tweet.createdAt));
  
  return (
    <div className="p-4 border-b border-gray-200 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
      <div className="flex gap-4">
        {/* Avatar */}
        <div className="flex-shrink-0">
          <img
            src={tweet.author.avatar || 'https://images.pexels.com/photos/771742/pexels-photo-771742.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'}
            alt={tweet.author.displayName}
            className="w-12 h-12 rounded-full"
          />
        </div>
        
        {/* Tweet Content */}
        <div className="flex-1 min-w-0">
          {/* Tweet Header */}
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-1 mb-1">
              <span className="font-bold hover:underline">
                {tweet.author.displayName}
              </span>
              {tweet.author.verified && (
                <Check size={16} className="text-blue-500" />
              )}
              {tweet.author.isBot && (
                <span className="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-xs px-2 py-0.5 rounded-full">
                  Bot
                </span>
              )}
              <span className="text-gray-500 dark:text-gray-400">
                @{tweet.author.username} · {timeAgo}
              </span>
            </div>
            <button className="text-gray-500 hover:text-blue-500">
              <MoreHorizontal size={16} />
            </button>
          </div>
          
          {/* Tweet Body */}
          <div className="mb-2 break-words">
            <p>{tweet.content}</p>
          </div>
          
          {/* Health Warning - Show for unhealthy tweets */}
          {isUnhealthy && (
            <div className="bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-md p-2 mb-2 flex items-center gap-2">
              <AlertCircle size={16} className="text-orange-500" />
              <span className="text-sm text-orange-700 dark:text-orange-300">
                This tweet may contain content related to unhealthy habits
              </span>
            </div>
          )}
          
          {/* Tweet Actions */}
          <div className="flex justify-between mt-3 text-gray-500 dark:text-gray-400">
            <button 
              onClick={() => setReplyModalOpen(true)}
              className="flex items-center gap-1 hover:text-blue-500"
            >
              <div className="p-1.5 rounded-full hover:bg-blue-50 dark:hover:bg-blue-900/20">
                <MessageCircle size={18} />
              </div>
              <span>{tweet.replies.length > 0 ? tweet.replies.length : ''}</span>
            </button>
            
            <button 
              onClick={() => retweet(tweet.id)}
              className={`flex items-center gap-1 ${isRetweeted ? 'text-green-500' : 'hover:text-green-500'}`}
            >
              <div className="p-1.5 rounded-full hover:bg-green-50 dark:hover:bg-green-900/20">
                <Repeat size={18} />
              </div>
              <span>{tweet.retweets.length > 0 ? tweet.retweets.length : ''}</span>
            </button>
            
            <button 
              onClick={() => likeTweet(tweet.id)}
              className={`flex items-center gap-1 ${isLiked ? 'text-red-500' : 'hover:text-red-500'}`}
            >
              <div className="p-1.5 rounded-full hover:bg-red-50 dark:hover:bg-red-900/20">
                <Heart size={18} className={isLiked ? 'fill-current' : ''} />
              </div>
              <span>{tweet.likes.length > 0 ? tweet.likes.length : ''}</span>
            </button>
            
            <button className="flex items-center gap-1 hover:text-blue-500">
              <div className="p-1.5 rounded-full hover:bg-blue-50 dark:hover:bg-blue-900/20">
                <Share size={18} />
              </div>
            </button>
          </div>
        </div>
      </div>
      
      {/* Show replies */}
      {showReplies && tweetReplies.length > 0 && (
        <div className="mt-4 pl-16">
          {tweetReplies.map(reply => (
            <TweetItem key={reply.id} tweet={reply} />
          ))}
        </div>
      )}
      
      {/* Reply Modal */}
      <TweetReplyModal 
        isOpen={replyModalOpen}
        onClose={() => setReplyModalOpen(false)}
        tweet={tweet}
      />
    </div>
  );
};