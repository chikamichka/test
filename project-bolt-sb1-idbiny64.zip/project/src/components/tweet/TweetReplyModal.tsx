import React from 'react';
import { X } from 'lucide-react';
import { Tweet } from '../../types/Tweet';
import { TweetItem } from './TweetItem';
import { CreateTweet } from './CreateTweet';

interface TweetReplyModalProps {
  isOpen: boolean;
  onClose: () => void;
  tweet: Tweet;
}

export const TweetReplyModal: React.FC<TweetReplyModalProps> = ({ 
  isOpen, 
  onClose, 
  tweet 
}) => {
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
      <div className="bg-white dark:bg-gray-900 rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white dark:bg-gray-900 p-4 border-b border-gray-200 dark:border-gray-800 flex justify-between items-center z-10">
          <h2 className="text-xl font-bold">Reply</h2>
          <button onClick={onClose} className="rounded-full p-2 hover:bg-gray-200 dark:hover:bg-gray-800">
            <X size={20} />
          </button>
        </div>
        
        <div className="p-4">
          {/* Original Tweet */}
          <TweetItem tweet={tweet} />
          
          <div className="ml-12 my-4 border-l-2 border-gray-200 dark:border-gray-800 pl-4">
            <p className="text-gray-500 dark:text-gray-400">
              Replying to <span className="text-blue-500">@{tweet.author.username}</span>
            </p>
          </div>
          
          {/* Create Reply */}
          <CreateTweet 
            placeholder="Tweet your reply"
            inReplyTo={tweet.id}
            onTweetCreated={onClose}
          />
        </div>
      </div>
    </div>
  );
};