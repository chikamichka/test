import React from 'react';
import { Tweet } from '../../types/Tweet';
import { TweetItem } from './TweetItem';

interface TweetListProps {
  tweets: Tweet[];
  showReplies?: boolean;
}

export const TweetList: React.FC<TweetListProps> = ({ tweets, showReplies = false }) => {
  // Filter out replies from main timeline unless showReplies is true
  const filteredTweets = showReplies 
    ? tweets
    : tweets.filter(tweet => !tweet.inReplyTo);
  
  if (filteredTweets.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-gray-500 dark:text-gray-400">
        <p className="text-2xl font-bold mb-2">No tweets yet</p>
        <p>When new tweets are created, they will appear here.</p>
      </div>
    );
  }

  return (
    <div>
      {filteredTweets.map(tweet => (
        <TweetItem key={tweet.id} tweet={tweet} showReplies={showReplies} />
      ))}
    </div>
  );
};