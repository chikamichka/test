import React from 'react';
import { Search, TrendingUp } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { HealthStats } from '../health/HealthStats';

export const RightSidebar: React.FC = () => {
  const { users } = useAuth();
  
  // Filter out the current user and get 3 random users to follow
  const suggestedUsers = users
    .filter(user => !user.isBot)
    .slice(0, 3);

  const trends = [
    { tag: '#HealthyEating', count: '32.5K tweets' },
    { tag: '#Fitness', count: '24.7K tweets' },
    { tag: '#MentalHealth', count: '18.9K tweets' },
    { tag: '#Nutrition', count: '15.2K tweets' },
    { tag: '#WellnessWednesday', count: '10.1K tweets' },
  ];

  return (
    <div className="h-screen sticky top-0 p-4 space-y-6 overflow-y-auto">
      {/* Search */}
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="text-gray-400" size={20} />
        </div>
        <input
          type="text"
          placeholder="Search Twitter"
          className="w-full bg-gray-100 dark:bg-gray-800 border-none rounded-full py-3 pl-10 pr-4 focus:ring-2 focus:ring-blue-500 focus:bg-white dark:focus:bg-gray-900"
        />
      </div>
      
      {/* Health Stats */}
      <HealthStats />
      
      {/* Trends */}
      <div className="bg-gray-50 dark:bg-gray-800 rounded-2xl p-4">
        <h2 className="text-xl font-bold mb-4">Trends for you</h2>
        <ul className="space-y-4">
          {trends.map((trend, i) => (
            <li key={i} className="hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg p-2 transition-colors">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-gray-500 dark:text-gray-400 text-sm">Trending</p>
                  <p className="font-bold">{trend.tag}</p>
                  <p className="text-gray-500 dark:text-gray-400 text-sm">{trend.count}</p>
                </div>
                <TrendingUp size={16} className="text-gray-500" />
              </div>
            </li>
          ))}
        </ul>
        <button className="text-blue-500 hover:text-blue-600 mt-4">
          Show more
        </button>
      </div>
      
      {/* Who to follow */}
      <div className="bg-gray-50 dark:bg-gray-800 rounded-2xl p-4">
        <h2 className="text-xl font-bold mb-4">Who to follow</h2>
        <ul className="space-y-4">
          {suggestedUsers.map((user) => (
            <li key={user.id} className="flex items-center justify-between hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg p-2 transition-colors">
              <div className="flex items-center gap-3">
                <img 
                  src={user.avatar} 
                  alt={user.displayName} 
                  className="w-10 h-10 rounded-full"
                />
                <div>
                  <p className="font-bold">{user.displayName}</p>
                  <p className="text-gray-500 dark:text-gray-400">@{user.username}</p>
                </div>
              </div>
              <button className="bg-black dark:bg-white text-white dark:text-black font-bold py-2 px-4 rounded-full text-sm">
                Follow
              </button>
            </li>
          ))}
        </ul>
        <button className="text-blue-500 hover:text-blue-600 mt-4">
          Show more
        </button>
      </div>
      
      {/* Footer links */}
      <div className="text-gray-500 dark:text-gray-400 text-xs">
        <div className="flex flex-wrap gap-2">
          <a href="#" className="hover:underline">Terms of Service</a>
          <a href="#" className="hover:underline">Privacy Policy</a>
          <a href="#" className="hover:underline">Cookie Policy</a>
          <a href="#" className="hover:underline">Accessibility</a>
          <a href="#" className="hover:underline">Ads info</a>
          <a href="#" className="hover:underline">More</a>
        </div>
        <p className="mt-2">© 2025 Twitter, Inc.</p>
      </div>
    </div>
  );
};