import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Home, User, Bell, Mail, Bookmark, 
  List, MoreHorizontal, LogOut, Twitter 
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const Sidebar: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const location = useLocation();
  
  const navItems = [
    { icon: <Home size={24} />, label: 'Home', path: '/' },
    { icon: <Bell size={24} />, label: 'Notifications', path: '/notifications' },
    { icon: <Mail size={24} />, label: 'Messages', path: '/messages' },
    { icon: <Bookmark size={24} />, label: 'Bookmarks', path: '/bookmarks' },
    { icon: <List size={24} />, label: 'Lists', path: '/lists' },
    { icon: <User size={24} />, label: 'Profile', path: `/profile/${currentUser?.username}` },
  ];

  return (
    <div className="h-screen sticky top-0 flex flex-col justify-between p-4">
      <div>
        {/* Logo */}
        <div className="flex items-center justify-center w-12 h-12 rounded-full hover:bg-blue-50 dark:hover:bg-blue-900/20 mb-4">
          <Twitter className="text-blue-500" size={28} />
        </div>
        
        {/* Navigation */}
        <nav className="mb-8">
          <ul className="space-y-2">
            {navItems.map((item) => (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={`flex items-center gap-4 p-3 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors ${
                    location.pathname === item.path 
                      ? 'font-bold' 
                      : 'font-normal'
                  }`}
                >
                  {item.icon}
                  <span className="text-xl">{item.label}</span>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        
        {/* Tweet Button */}
        <button className="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-4 rounded-full transition">
          Tweet
        </button>
      </div>
      
      {/* User Profile */}
      {currentUser && (
        <div className="flex items-center gap-2 p-3 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors cursor-pointer mt-auto">
          <img 
            src={currentUser.avatar || 'https://images.pexels.com/photos/771742/pexels-photo-771742.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'} 
            alt={currentUser.displayName} 
            className="w-10 h-10 rounded-full"
          />
          <div className="flex-1 min-w-0">
            <p className="font-bold truncate">{currentUser.displayName}</p>
            <p className="text-gray-500 dark:text-gray-400 truncate">@{currentUser.username}</p>
          </div>
          <div className="flex items-center gap-1">
            <MoreHorizontal size={20} />
            <button onClick={logout} className="ml-2 text-red-500">
              <LogOut size={20} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};