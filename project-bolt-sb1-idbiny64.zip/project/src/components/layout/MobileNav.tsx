import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Search, Bell, Mail, User } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const MobileNav: React.FC = () => {
  const location = useLocation();
  const { currentUser } = useAuth();
  
  const navItems = [
    { icon: <Home size={24} />, path: '/' },
    { icon: <Search size={24} />, path: '/explore' },
    { icon: <Bell size={24} />, path: '/notifications' },
    { icon: <Mail size={24} />, path: '/messages' },
    { 
      icon: currentUser?.avatar 
        ? <img 
            src={currentUser.avatar} 
            alt={currentUser.displayName} 
            className="w-6 h-6 rounded-full" 
          /> 
        : <User size={24} />, 
      path: `/profile/${currentUser?.username}` 
    },
  ];

  return (
    <nav className="flex justify-around py-3">
      {navItems.map((item) => (
        <Link
          key={item.path}
          to={item.path}
          className={`p-2 rounded-full ${
            location.pathname === item.path
              ? 'text-blue-500'
              : 'text-gray-500 dark:text-gray-400'
          }`}
        >
          {item.icon}
        </Link>
      ))}
    </nav>
  );
};