import React from 'react';
import { Sidebar } from './Sidebar';
import { MobileNav } from './MobileNav';
import { RightSidebar } from './RightSidebar';
import { useAuth } from '../../context/AuthContext';
import { Login } from '../../pages/Login';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <Login />;
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto flex">
        {/* Desktop Sidebar */}
        <div className="hidden md:block w-64 shrink-0">
          <Sidebar />
        </div>
        
        {/* Main Content */}
        <main className="flex-1 border-x border-gray-200 dark:border-gray-800 min-h-screen">
          {children}
        </main>
        
        {/* Right Sidebar - Trending, Who to follow */}
        <div className="hidden lg:block w-80 shrink-0">
          <RightSidebar />
        </div>
      </div>
      
      {/* Mobile Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800">
        <MobileNav />
      </div>
    </div>
  );
};