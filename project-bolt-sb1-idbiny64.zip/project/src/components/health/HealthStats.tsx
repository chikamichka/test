import React, { useMemo } from 'react';
import { Leaf, AlertCircle } from 'lucide-react';
import { useHealth } from '../../context/HealthContext';

export const HealthStats: React.FC = () => {
  const { classifications } = useHealth();
  
  // Calculate health metrics
  const stats = useMemo(() => {
    const healthyCount = Object.values(classifications).filter(
      c => c.category === 'Healthy'
    ).length;
    
    const unhealthyCount = Object.values(classifications).filter(
      c => c.category === 'Unhealthy'
    ).length;
    
    const total = healthyCount + unhealthyCount;
    
    const healthyPercentage = total > 0 
      ? Math.round((healthyCount / total) * 100) 
      : 0;
      
    return {
      healthyCount,
      unhealthyCount,
      total,
      healthyPercentage
    };
  }, [classifications]);
  
  return (
    <div className="bg-green-50 dark:bg-green-900/20 rounded-2xl p-4">
      <h2 className="text-xl font-bold mb-2 flex items-center gap-2">
        <Leaf className="text-green-500" size={20} />
        Health Insights
      </h2>
      
      {stats.total > 0 ? (
        <>
          <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
            Content health analysis of your timeline
          </p>
          
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Healthy content</span>
                <span className="font-medium">{stats.healthyPercentage}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                <div 
                  className="bg-green-500 h-2.5 rounded-full" 
                  style={{ width: `${stats.healthyPercentage}%` }}
                ></div>
              </div>
            </div>
            
            <div className="flex justify-between">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-500">{stats.healthyCount}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">Healthy</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-orange-500">{stats.unhealthyCount}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">Unhealthy</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold">{stats.total}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">Total</p>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300">
          <AlertCircle size={16} />
          <p>Not enough content to analyze yet.</p>
        </div>
      )}
    </div>
  );
};