import { User } from './User';

export interface Tweet {
  id: string;
  content: string;
  authorId: string;
  author: User;
  likes: string[];
  retweets: string[];
  replies: string[];
  createdAt: string;
  inReplyTo?: string;
}