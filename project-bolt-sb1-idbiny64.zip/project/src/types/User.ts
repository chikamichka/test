export interface User {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  bio: string;
  following: string[];
  followers: string[];
  isBot?: boolean;
  verified?: boolean;
}