export interface HealthClassification {
  category: 'Healthy' | 'Unhealthy';
  confidence: number;
  detail: string;
  persuasive_message: string;
}