import React from 'react';
import { Settings } from 'lucide-react';
import { CreateTweet } from '../components/tweet/CreateTweet';
import { TweetList } from '../components/tweet/TweetList';
import { useTweets } from '../context/TweetContext';
import { useHealth } from '../context/HealthContext';

export const Home: React.FC = () => {
  const { tweets } = useTweets();
  const { healthResponses } = useHealth();
  
  // Combine regular tweets and health bot responses
  const allTweets = [...tweets, ...healthResponses].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
  
  return (
    <div>
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md p-4 border-b border-gray-200 dark:border-gray-800">
        <div className="flex justify-between items-center">
          <h1 className="text-xl font-bold">Home</h1>
          <button className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800">
            <Settings size={20} />
          </button>
        </div>
      </header>
      
      {/* Create Tweet */}
      <CreateTweet />
      
      {/* Timeline */}
      <TweetList tweets={allTweets} />
    </div>
  );
};