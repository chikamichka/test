import React from 'react';
import { useParams } from 'react-router-dom';
import { Calendar, ArrowLeft, MapPin, Link as LinkIcon } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTweets } from '../context/TweetContext';
import { TweetList } from '../components/tweet/TweetList';
import { formatDate } from '../utils/dateUtils';

export const Profile: React.FC = () => {
  const { username } = useParams<{ username: string }>();
  const { users } = useAuth();
  const { getUserTweets } = useTweets();
  
  // Find user profile
  const user = users.find(u => u.username === username);
  
  // Get tweets by this user
  const userTweets = getUserTweets(username || '');
  
  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center h-96">
        <h2 className="text-2xl font-bold mb-2">User not found</h2>
        <p className="text-gray-500 dark:text-gray-400">
          The user @{username} doesn't exist.
        </p>
      </div>
    );
  }
  
  return (
    <div>
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md px-4 py-2 border-b border-gray-200 dark:border-gray-800">
        <div className="flex items-center gap-6">
          <button className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="text-xl font-bold">{user.displayName}</h1>
            <p className="text-gray-500 dark:text-gray-400 text-sm">
              {userTweets.length} {userTweets.length === 1 ? 'Tweet' : 'Tweets'}
            </p>
          </div>
        </div>
      </header>
      
      {/* Cover Photo */}
      <div className="h-48 bg-blue-500"></div>
      
      {/* Profile Info */}
      <div className="px-4 pb-4 border-b border-gray-200 dark:border-gray-800 relative">
        {/* Avatar */}
        <div className="absolute -top-12 left-4 bg-white dark:bg-gray-900 rounded-full p-1">
          <img
            src={user.avatar || 'https://images.pexels.com/photos/771742/pexels-photo-771742.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'}
            alt={user.displayName}
            className="w-24 h-24 rounded-full"
          />
        </div>
        
        {/* Follow Button */}
        <div className="flex justify-end pt-2 mb-16">
          <button className="rounded-full px-4 py-2 font-bold border border-gray-300 dark:border-gray-700 hover:bg-gray-200 dark:hover:bg-gray-800">
            {user.isBot ? 'Follow Bot' : 'Follow'}
          </button>
        </div>
        
        {/* User Info */}
        <div className="mb-4">
          <h2 className="text-xl font-bold flex items-center gap-1">
            {user.displayName}
            {user.verified && (
              <span className="bg-blue-500 text-white rounded-full p-1">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 12L11 14L15 10M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </span>
            )}
          </h2>
          <p className="text-gray-500 dark:text-gray-400">@{user.username}</p>
          
          <p className="my-3">{user.bio}</p>
          
          <div className="flex flex-wrap gap-4 text-gray-500 dark:text-gray-400 text-sm">
            <div className="flex items-center gap-1">
              <MapPin size={16} />
              <span>San Francisco, CA</span>
            </div>
            <div className="flex items-center gap-1">
              <LinkIcon size={16} />
              <a href="#" className="text-blue-500 hover:underline">example.com</a>
            </div>
            <div className="flex items-center gap-1">
              <Calendar size={16} />
              <span>Joined {formatDate(new Date())}</span>
            </div>
          </div>
          
          <div className="flex gap-4 mt-3">
            <p>
              <span className="font-bold text-black dark:text-white">{user.following.length}</span>
              <span className="text-gray-500 dark:text-gray-400"> Following</span>
            </p>
            <p>
              <span className="font-bold text-black dark:text-white">{user.followers.length}</span>
              <span className="text-gray-500 dark:text-gray-400"> Followers</span>
            </p>
          </div>
        </div>
      </div>
      
      {/* Tabs */}
      <div className="flex border-b border-gray-200 dark:border-gray-800">
        <button className="flex-1 py-4 font-bold border-b-2 border-blue-500">Tweets</button>
        <button className="flex-1 py-4 text-gray-500 dark:text-gray-400">Replies</button>
        <button className="flex-1 py-4 text-gray-500 dark:text-gray-400">Media</button>
        <button className="flex-1 py-4 text-gray-500 dark:text-gray-400">Likes</button>
      </div>
      
      {/* Tweets */}
      <TweetList tweets={userTweets} />
    </div>
  );
};