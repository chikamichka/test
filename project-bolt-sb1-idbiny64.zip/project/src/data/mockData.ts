import { User } from '../types/User';
import { Tweet } from '../types/Tweet';
import { Twitter, Leaf, Activity, Coffee, BookOpen } from 'lucide-react';

// Mock users including the health advisor bot
export const mockUsers: User[] = [
  {
    id: '1',
    username: 'johndoe',
    displayName: 'John Doe',
    avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    bio: 'Software developer and tech enthusiast',
    following: ['2', '3', 'health-bot'],
    followers: ['2', '3', 'health-bot']
  },
  {
    id: '2',
    username: 'janedoe',
    displayName: 'Jane Doe',
    avatar: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    bio: 'UX designer and coffee lover',
    following: ['1', '3', 'health-bot'],
    followers: ['1', 'health-bot']
  },
  {
    id: '3',
    username: 'mikesmith',
    displayName: 'Mike Smith',
    avatar: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    bio: 'Traveler and photographer',
    following: ['1', '2', 'health-bot'],
    followers: ['1', '2', 'health-bot']
  },
  {
    id: 'health-bot',
    username: 'healthadvisor',
    displayName: 'Health Advisor',
    avatar: '',
    bio: 'Promoting healthy choices with helpful tips and reminders. Let\'s live our best, healthiest lives together!',
    following: ['1', '2', '3'],
    followers: ['1', '2', '3'],
    isBot: true,
    verified: true
  }
];

// Mock tweets
export const mockTweets: Tweet[] = [
  {
    id: 't1',
    content: 'Just finished a 5K run! Feeling energized and ready for the day. #fitness #running',
    authorId: '1',
    author: mockUsers[0],
    likes: ['2', 'health-bot'],
    retweets: [],
    replies: [],
    createdAt: '2025-01-15T09:30:00Z'
  },
  {
    id: 't2',
    content: 'Enjoying a large pizza and soda for dinner tonight. Perfect way to end a long week!',
    authorId: '2',
    author: mockUsers[1],
    likes: ['1'],
    retweets: [],
    replies: ['t5'],
    createdAt: '2025-01-15T19:45:00Z'
  },
  {
    id: 't3',
    content: 'Just published my latest article on sustainable design practices. Check it out! #UXDesign #Sustainability',
    authorId: '2',
    author: mockUsers[1],
    likes: ['1', '3'],
    retweets: ['1'],
    replies: [],
    createdAt: '2025-01-14T14:20:00Z'
  },
  {
    id: 't4',
    content: 'Nothing better than some good old junk food on a lazy Sunday afternoon.',
    authorId: '3',
    author: mockUsers[2],
    likes: [],
    retweets: [],
    replies: ['t6'],
    createdAt: '2025-01-13T16:10:00Z'
  },
  {
    id: 't5',
    content: 'Pizza can be delicious AND nutritious! Try making your own with whole grain crust, fresh veggies, and lean protein. Your taste buds and body will thank you! #HealthyPizza #EatWell',
    authorId: 'health-bot',
    author: mockUsers[3],
    likes: ['1', '3'],
    retweets: ['1'],
    replies: [],
    createdAt: '2025-01-15T19:50:00Z',
    inReplyTo: 't2'
  },
  {
    id: 't6',
    content: 'Enjoying treats occasionally is part of a balanced lifestyle! Consider pairing them with nutrient-rich foods and staying hydrated. Small changes can make a big difference in how you feel afterward! #BalancedChoices',
    authorId: 'health-bot',
    author: mockUsers[3],
    likes: ['2', '3'],
    retweets: [],
    replies: [],
    createdAt: '2025-01-13T16:15:00Z',
    inReplyTo: 't4'
  }
];

// Health advisor bot representation
export const mockHealthBot = mockUsers.find(user => user.username === 'healthadvisor');