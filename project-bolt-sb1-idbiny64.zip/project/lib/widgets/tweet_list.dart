import 'package:flutter/material.dart';
import 'package:twitter_health_clone/models/tweet.dart';
import 'package:twitter_health_clone/widgets/tweet_item.dart';

class TweetList extends StatelessWidget {
  final List<Tweet> tweets;
  final bool showReplies;

  const TweetList({
    super.key,
    required this.tweets,
    this.showReplies = false,
  });

  @override
  Widget build(BuildContext context) {
    final filteredTweets = showReplies
        ? tweets
        : tweets.where((tweet) => tweet.inReplyTo == null).toList();

    if (filteredTweets.isEmpty) {
      return const Center(
        child: Text('No tweets yet'),
      );
    }

    return ListView.builder(
      itemCount: filteredTweets.length,
      itemBuilder: (context, index) {
        return TweetItem(tweet: filteredTweets[index]);
      },
    );
  }
}