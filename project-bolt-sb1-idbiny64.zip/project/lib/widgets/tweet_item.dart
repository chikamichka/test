import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twitter_health_clone/models/tweet.dart';
import 'package:twitter_health_clone/providers/auth_provider.dart';
import 'package:twitter_health_clone/providers/health_provider.dart';
import 'package:intl/intl.dart';

class TweetItem extends StatelessWidget {
  final Tweet tweet;

  const TweetItem({
    super.key,
    required this.tweet,
  });

  @override
  Widget build(BuildContext context) {
    final currentUser = context.watch<AuthProvider>().currentUser;
    final healthClassification = context.watch<HealthProvider>().classifications[tweet.id];

    final isLiked = currentUser != null && tweet.likes.contains(currentUser.id);
    final isRetweeted = currentUser != null && tweet.retweets.contains(currentUser.id);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundImage: NetworkImage(currentUser?.avatar ?? ''),
                ),
                const SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      currentUser?.displayName ?? '',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text(
                      '@${currentUser?.username ?? ''}',
                      style: TextStyle(
                        color: Theme.of(context).textTheme.bodySmall?.color,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(tweet.content),
            if (healthClassification?.category == 'Unhealthy')
              Container(
                margin: const EdgeInsets.only(top: 8),
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.orange.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.warning, color: Colors.orange),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        healthClassification?.persuasiveMessage ?? '',
                        style: const TextStyle(color: Colors.orange),
                      ),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                IconButton(
                  icon: const Icon(Icons.comment),
                  onPressed: () {
                    // TODO: Implement reply
                  },
                ),
                IconButton(
                  icon: Icon(
                    Icons.repeat,
                    color: isRetweeted ? Colors.green : null,
                  ),
                  onPressed: () {
                    // TODO: Implement retweet
                  },
                ),
                IconButton(
                  icon: Icon(
                    isLiked ? Icons.favorite : Icons.favorite_border,
                    color: isLiked ? Colors.red : null,
                  ),
                  onPressed: () {
                    // TODO: Implement like
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.share),
                  onPressed: () {
                    // TODO: Implement share
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}