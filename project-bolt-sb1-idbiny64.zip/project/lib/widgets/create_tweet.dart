import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twitter_health_clone/providers/tweet_provider.dart';
import 'package:twitter_health_clone/providers/auth_provider.dart';
import 'package:twitter_health_clone/models/tweet.dart';

class CreateTweet extends StatefulWidget {
  final String? inReplyTo;

  const CreateTweet({
    super.key,
    this.inReplyTo,
  });

  @override
  State<CreateTweet> createState() => _CreateTweetState();
}

class _CreateTweetState extends State<CreateTweet> {
  final _controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final currentUser = context.watch<AuthProvider>().currentUser;

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                backgroundImage: NetworkImage(currentUser?.avatar ?? ''),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _controller,
                  decoration: const InputDecoration(
                    hintText: "What's happening?",
                    border: InputBorder.none,
                  ),
                  maxLines: null,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.image),
                    onPressed: () {
                      // TODO: Implement image upload
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.gif),
                    onPressed: () {
                      // TODO: Implement GIF selection
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.emoji_emotions),
                    onPressed: () {
                      // TODO: Implement emoji picker
                    },
                  ),
                ],
              ),
              ElevatedButton(
                onPressed: _controller.text.isEmpty
                    ? null
                    : () {
                        final tweet = Tweet(
                          id: DateTime.now().toString(),
                          content: _controller.text,
                          authorId: currentUser?.id ?? '',
                          createdAt: DateTime.now(),
                          likes: [],
                          retweets: [],
                          replies: [],
                          inReplyTo: widget.inReplyTo,
                        );
                        
                        context.read<TweetProvider>().addTweet(tweet);
                        _controller.clear();
                        
                        if (widget.inReplyTo != null) {
                          Navigator.pop(context);
                        }
                      },
                child: Text(widget.inReplyTo != null ? 'Reply' : 'Tweet'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}