class User {
  final String id;
  final String username;
  final String displayName;
  final String avatar;
  final String bio;
  final List<String> following;
  final List<String> followers;
  final bool isBot;
  final bool verified;

  User({
    required this.id,
    required this.username,
    required this.displayName,
    required this.avatar,
    required this.bio,
    required this.following,
    required this.followers,
    this.isBot = false,
    this.verified = false,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'],
      username: json['username'],
      displayName: json['displayName'],
      avatar: json['avatar'],
      bio: json['bio'],
      following: List<String>.from(json['following']),
      followers: List<String>.from(json['followers']),
      isBot: json['isBot'] ?? false,
      verified: json['verified'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'username': username,
      'displayName': displayName,
      'avatar': avatar,
      'bio': bio,
      'following': following,
      'followers': followers,
      'isBot': isBot,
      'verified': verified,
    };
  }
}