class HealthClassification {
  final String category;
  final double confidence;
  final String detail;
  final String persuasiveMessage;

  HealthClassification({
    required this.category,
    required this.confidence,
    required this.detail,
    required this.persuasiveMessage,
  });

  factory HealthClassification.fromJson(Map<String, dynamic> json) {
    return HealthClassification(
      category: json['category'],
      confidence: json['confidence'].toDouble(),
      detail: json['detail'],
      persuasiveMessage: json['persuasive_message'],
    );
  }
}