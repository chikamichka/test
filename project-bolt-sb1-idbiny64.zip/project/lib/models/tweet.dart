class Tweet {
  final String id;
  final String content;
  final String authorId;
  final DateTime createdAt;
  final List<String> likes;
  final List<String> retweets;
  final List<String> replies;
  final String? inReplyTo;

  Tweet({
    required this.id,
    required this.content,
    required this.authorId,
    required this.createdAt,
    required this.likes,
    required this.retweets,
    required this.replies,
    this.inReplyTo,
  });

  factory Tweet.fromJson(Map<String, dynamic> json) {
    return Tweet(
      id: json['id'],
      content: json['content'],
      authorId: json['authorId'],
      createdAt: DateTime.parse(json['createdAt']),
      likes: List<String>.from(json['likes']),
      retweets: List<String>.from(json['retweets']),
      replies: List<String>.from(json['replies']),
      inReplyTo: json['inReplyTo'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'content': content,
      'authorId': authorId,
      'createdAt': createdAt.toIso8601String(),
      'likes': likes,
      'retweets': retweets,
      'replies': replies,
      'inReplyTo': inReplyTo,
    };
  }
}