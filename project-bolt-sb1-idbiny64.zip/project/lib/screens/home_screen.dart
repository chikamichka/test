import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twitter_health_clone/providers/tweet_provider.dart';
import 'package:twitter_health_clone/widgets/tweet_list.dart';
import 'package:twitter_health_clone/widgets/create_tweet.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              // TODO: Implement settings
            },
          ),
        ],
      ),
      body: Column(
        children: [
          const CreateTweet(),
          Expanded(
            child: Consumer<TweetProvider>(
              builder: (context, tweetProvider, _) {
                return TweetList(tweets: tweetProvider.tweets);
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            builder: (context) => const CreateTweet(),
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}