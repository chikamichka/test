import 'package:flutter/foundation.dart';
import 'package:twitter_health_clone/models/user.dart';
import 'package:shared_preferences.dart';
import 'dart:convert';

class AuthProvider with ChangeNotifier {
  User? _currentUser;
  bool _isAuthenticated = false;

  User? get currentUser => _currentUser;
  bool get isAuthenticated => _isAuthenticated;

  Future<void> login(String username, String password) async {
    // Simulate API call
    await Future.delayed(const Duration(seconds: 1));
    
    // Mock user data
    _currentUser = User(
      id: '1',
      username: username,
      displayName: 'John Doe',
      avatar: 'https://via.placeholder.com/150',
      bio: 'Flutter Developer',
      following: [],
      followers: [],
    );
    
    _isAuthenticated = true;
    
    // Save to local storage
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user', jsonEncode(_currentUser?.toJson()));
    
    notifyListeners();
  }

  Future<void> logout() async {
    _currentUser = null;
    _isAuthenticated = false;
    
    // Clear local storage
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('user');
    
    notifyListeners();
  }

  Future<void> checkAuthStatus() async {
    final prefs = await SharedPreferences.getInstance();
    final userData = prefs.getString('user');
    
    if (userData != null) {
      _currentUser = User.fromJson(jsonDecode(userData));
      _isAuthenticated = true;
      notifyListeners();
    }
  }
}