import 'package:flutter/foundation.dart';
import 'package:twitter_health_clone/models/tweet.dart';

class TweetProvider with ChangeNotifier {
  final List<Tweet> _tweets = [];

  List<Tweet> get tweets => _tweets;

  void addTweet(Tweet tweet) {
    _tweets.insert(0, tweet);
    notifyListeners();
  }

  void likeTweet(String tweetId, String userId) {
    final tweetIndex = _tweets.indexWhere((t) => t.id == tweetId);
    if (tweetIndex != -1) {
      final tweet = _tweets[tweetIndex];
      final likes = List<String>.from(tweet.likes);
      
      if (likes.contains(userId)) {
        likes.remove(userId);
      } else {
        likes.add(userId);
      }
      
      _tweets[tweetIndex] = Tweet(
        id: tweet.id,
        content: tweet.content,
        authorId: tweet.authorId,
        createdAt: tweet.createdAt,
        likes: likes,
        retweets: tweet.retweets,
        replies: tweet.replies,
        inReplyTo: tweet.inReplyTo,
      );
      
      notifyListeners();
    }
  }

  void retweet(String tweetId, String userId) {
    final tweetIndex = _tweets.indexWhere((t) => t.id == tweetId);
    if (tweetIndex != -1) {
      final tweet = _tweets[tweetIndex];
      final retweets = List<String>.from(tweet.retweets);
      
      if (retweets.contains(userId)) {
        retweets.remove(userId);
      } else {
        retweets.add(userId);
      }
      
      _tweets[tweetIndex] = Tweet(
        id: tweet.id,
        content: tweet.content,
        authorId: tweet.authorId,
        createdAt: tweet.createdAt,
        likes: tweet.likes,
        retweets: retweets,
        replies: tweet.replies,
        inReplyTo: tweet.inReplyTo,
      );
      
      notifyListeners();
    }
  }
}