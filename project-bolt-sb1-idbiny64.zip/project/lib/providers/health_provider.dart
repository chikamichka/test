import 'package:flutter/foundation.dart';
import 'package:twitter_health_clone/models/health_classification.dart';
import 'package:twitter_health_clone/services/health_service.dart';

class HealthProvider with ChangeNotifier {
  final Map<String, HealthClassification> _classifications = {};

  Map<String, HealthClassification> get classifications => _classifications;

  Future<void> classifyTweet(String tweetId, String content) async {
    try {
      final classification = await HealthService.classifyTweet(content);
      _classifications[tweetId] = classification;
      notifyListeners();
    } catch (e) {
      print('Error classifying tweet: $e');
    }
  }
}