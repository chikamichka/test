import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:twitter_health_clone/models/health_classification.dart';

class HealthService {
  static const String apiUrl = 'http://127.0.0.1:8000/classify_post';

  static Future<HealthClassification> classifyTweet(String text) async {
    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': text}),
      );

      if (response.statusCode == 200) {
        return HealthClassification.fromJson(jsonDecode(response.body));
      } else {
        throw Exception('Failed to classify tweet');
      }
    } catch (e) {
      print('Error classifying tweet: $e');
      return HealthClassification(
        category: 'Healthy',
        confidence: 0,
        detail: 'Error connecting to classification service',
        persuasiveMessage: '',
      );
    }
  }
}