import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twitter_health_clone/providers/auth_provider.dart';
import 'package:twitter_health_clone/providers/tweet_provider.dart';
import 'package:twitter_health_clone/providers/health_provider.dart';
import 'package:twitter_health_clone/screens/home_screen.dart';
import 'package:twitter_health_clone/screens/login_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => TweetProvider()),
        ChangeNotifierProvider(create: (_) => HealthProvider()),
      ],
      child: MaterialApp(
        title: 'Twitter Health Clone',
        theme: ThemeData(
          primarySwatch: Colors.blue,
          brightness: Brightness.light,
        ),
        darkTheme: ThemeData(
          brightness: Brightness.dark,
        ),
        home: Consumer<AuthProvider>(
          builder: (context, auth, _) {
            return auth.isAuthenticated ? const HomeScreen() : const LoginScreen();
          },
        ),
      ),
    );
  }
}